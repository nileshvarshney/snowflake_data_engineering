def my_upper(s:str) -> str:
    return s.upper()